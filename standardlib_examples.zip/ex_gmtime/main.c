
#include <stdio.h>
#include <time.h>

int main()
{
  time_t now;
  struct tm *the_time;

  now = time(NULL);
  the_time = gmtime(&now);
  
  printf("the day is %s\n", asctime(the_time));

  printf("the year is %d\n", the_time->tm_year + 1900);
  
  return 0;
}
