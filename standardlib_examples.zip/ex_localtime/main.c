
#include <stdio.h>
#include <time.h>

int main()
{
  time_t now;
  struct tm *the_time;

  now = time(NULL);
  the_time = localtime(&now);
  
  printf("the day is %s\n", asctime(the_time));
  
  return 0;
}
