
#include <stdio.h>
#include <time.h>

#define BUF_SIZE 250

int main()
{
  int n;
  char buffer[BUF_SIZE];
  time_t now;
  struct tm *the_time;

  now = time(NULL);
  the_time = localtime(&now);

  n = strftime(buffer, BUF_SIZE, "%A", the_time);
  
  printf("the day is %s\n", buffer);
  
  return 0;
}
