
#include <stdio.h>
#include <errno.h>
#define FILENAME "junk.txt"

int main()
{
  FILE *fi;
  
  if( (fi = fopen(FILENAME, "r")) != NULL )
    {
      printf("file is opened\n");
      fclose(fi);
    }
  else
    {
      perror("fopen");
    }
  
  return 0;
}



