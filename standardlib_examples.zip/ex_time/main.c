
#include <stdio.h>
#include <time.h>

int main()
{
  time_t    the_day;

  time(&the_day);

  printf("the day is %s\n", ctime(&the_day));
  
  return 0;
}
