
#include <stdio.h>
#include <stdbool.h>

bool my_true()
{
  return true;
}

bool my_false()
{
  return false;
}

int main()
{
  if( my_true() ) printf("True\n");
  if( !my_false() ) printf("False\n");

  return 0;
}



