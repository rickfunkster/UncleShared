
#include <stdio.h>
#include <string.h>
#include <errno.h>

int main()
{
  FILE *fi;
  
  if( (fi = fopen("junk.txt", "r")) != NULL )
    {
      printf("file is opened\n");
      fclose(fi);
    }
  else
    {
      printf("The error is: %s\n", strerror(errno));
    }
  
  return 0;
}



