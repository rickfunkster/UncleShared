
#include <stdio.h>
#include <time.h>

int main()
{
  while(1)
    {
      
      printf("cpu time is %u\n", clock());
    }
  
  return 0;
}
