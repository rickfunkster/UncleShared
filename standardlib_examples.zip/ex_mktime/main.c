
#include <stdio.h>
#include <time.h>

int main()
{
  time_t    the_day;
  struct tm the_time;

  the_time.tm_sec = 0;
  the_time.tm_min = 0;
  the_time.tm_hour = 13;
  the_time.tm_mday = 15;
  the_time.tm_mon  = 10;
  the_time.tm_year = 1999 - 1900;

  the_day = mktime(&the_time);

  printf("the day is %s\n", ctime(&the_day));
  
  return 0;
}
