
#include <stdio.h>
#include <time.h>

int main()
{
  time_t    the_day;

  the_day = time(NULL);
  
  printf("the day is %s\n", ctime(&the_day));
  
  return 0;
}
