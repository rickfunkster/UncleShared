import android.annotation.SuppressLint
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import edu.arizona.cast.rickfunk.glucosemonitor.GlucoseHistoryFragment
import edu.arizona.cast.rickfunk.glucosemonitor.R
import edu.arizona.cast.rickfunk.glucosemonitor.databinding.FragmentGlucoseInputBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class GlucoseInputFragment : Fragment() {

    private var _binding: FragmentGlucoseInputBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentGlucoseInputBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("WeekBasedYear")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Get the current date and format it
        val currentDate = Calendar.getInstance().time
        val dateFormat = SimpleDateFormat("EEE, MMM d, YYYY", Locale.getDefault())
        val formattedDate = dateFormat.format(currentDate)
        binding.dateButton.text = formattedDate

        // Handle the date button press to evaluate glucose levels
        binding.dateButton.setOnClickListener {
            val fasting = binding.fastingInput.text.toString().toIntOrNull() ?: -1
            val breakfast = binding.breakfastInput.text.toString().toIntOrNull() ?: -1
            val lunch = binding.lunchInput.text.toString().toIntOrNull() ?: -1
            val dinner = binding.dinnerInput.text.toString().toIntOrNull() ?: -1

            // Evaluate glucose levels and display results
            val results = evaluateGlucoseLevels(fasting, breakfast, lunch, dinner)
            binding.resultsTextView.text = results
        }

        // Handle clear button
        binding.clearButton.setOnClickListener {
            binding.fastingInput.text.clear()
            binding.breakfastInput.text.clear()
            binding.lunchInput.text.clear()
            binding.dinnerInput.text.clear()
        }

        // Handle history button
        binding.historyButton.setOnClickListener {
            // Navigate to the history list fragment
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, GlucoseHistoryFragment())
                .addToBackStack(null)
                .commit()
        }
    }

    private fun evaluateGlucoseLevels(fasting: Int, breakfast: Int, lunch: Int, dinner: Int): SpannableString {
        val fastingStatus = if (fasting in 70..99) "NORMAL" else if (fasting < 70) "HYPOGLYCEMIC" else "ABNORMAL"
        val breakfastStatus = if (breakfast <= 140) "NORMAL" else "ABNORMAL"
        val lunchStatus = if (lunch <= 140) "NORMAL" else "ABNORMAL"
        val dinnerStatus = if (dinner <= 140) "NORMAL" else "ABNORMAL"

        // Create the result string
        val resultText = """
            Fasting: $fastingStatus
            Breakfast: $breakfastStatus
            Lunch: $lunchStatus
            Dinner: $dinnerStatus
            IsNormal: ${fastingStatus == "NORMAL" && breakfastStatus == "NORMAL" && lunchStatus == "NORMAL" && dinnerStatus == "NORMAL"}
        """.trimIndent()

        // Create a SpannableString to set colors
        val spannableString = SpannableString(resultText)

        // Apply colors based on the status
        applyColor(spannableString, "Fasting: ", fastingStatus)
        applyColor(spannableString, "Breakfast: ", breakfastStatus)
        applyColor(spannableString, "Lunch: ", lunchStatus)
        applyColor(spannableString, "Dinner: ", dinnerStatus)

        return spannableString
    }

    private fun applyColor(spannableString: SpannableString, label: String, status: String) {
        val start = spannableString.indexOf(label) + label.length
        val end = start + status.length
        val color = when (status) {
            "NORMAL" -> 0xFF00FF00.toInt() // Green
            "HYPOGLYCEMIC" -> 0xFFFF0000.toInt() // Red
            "ABNORMAL" -> 0xFF0000FF.toInt() // BLUE
            else -> 0xFF000000.toInt() // Default color (black)
        }
        spannableString.setSpan(ForegroundColorSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
