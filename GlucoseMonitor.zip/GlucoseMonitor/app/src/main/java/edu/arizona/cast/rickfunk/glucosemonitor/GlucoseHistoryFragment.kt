package edu.arizona.cast.rickfunk.glucosemonitor

import GlucoseAdapter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import java.util.*
import androidx.recyclerview.widget.LinearLayoutManager
import edu.arizona.cast.rickfunk.glucosemonitor.databinding.FragmentGlucoseHistoryBinding

class GlucoseHistoryFragment : Fragment() {

    private var _binding: FragmentGlucoseHistoryBinding? = null
    private val binding get() = _binding!!
    private val glucoseList = mutableListOf<Glucose>() // Simulate some data

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentGlucoseHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Fill sample glucose data (in a real app, this data would come from a database or file)
        val calendar = GregorianCalendar(Calendar.getInstance(). get(Calendar.YEAR),
            Calendar.getInstance().get(Calendar.MONTH),
            Calendar.getInstance().get(Calendar.DAY_OF_MONTH))

        for (i in 0..99) {
            val glucoseObject = Glucose(
                calendar.time,
                (60..180).random(),
                (60..180).random(),
                (60..180).random(),
                (60..180).random()
            )
            glucoseList.add(glucoseObject)
            calendar.add(Calendar.DATE,-1)
        }

        // Set up RecyclerView
        binding.glucoseRecyclerView.layoutManager = LinearLayoutManager(context)
        binding.glucoseRecyclerView.adapter = GlucoseAdapter(glucoseList) {
            Toast.makeText(requireContext(), it.toString(), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}