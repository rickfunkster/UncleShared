import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import edu.arizona.cast.rickfunk.glucosemonitor.Glucose
import edu.arizona.cast.rickfunk.glucosemonitor.databinding.ListItemGlucoseBinding

class GlucoseAdapter(
    private val glucoses: List<Glucose>,
    private val onItemClick: (Glucose) -> Unit
) : RecyclerView.Adapter<GlucoseAdapter.GlucoseViewHolder>() {

    class GlucoseViewHolder(private val binding: ListItemGlucoseBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(glucose: Glucose, onItemClick: (Glucose) -> Unit) {
            binding.glucoseDate.text = glucose.date.toString()
            binding.glucoseAverage.text = "Average: ${
                (glucose.fasting + glucose.breakfast + glucose.lunch + glucose.dinner) / 4
            } mg/dl"

            val status = when {
                glucose.fasting < 70 || glucose.breakfast < 70 || glucose.lunch < 70 || glucose.dinner < 70 -> "Low"
                glucose.fasting in 70 .. 99 && glucose.breakfast <= 140 && glucose.lunch <= 140 && glucose.dinner <= 140 -> "Normal"
                else -> "Abnormal"
            }
            if (status == "Low")  {
                binding.glucoseTag.setTextColor(Color.BLUE) }
            if (status == "Normal")  {
                binding.glucoseTag.setTextColor(Color.GREEN) }
            if (status == "Abnormal")  {
                binding.glucoseTag.setTextColor(Color.RED)
            }
            binding.glucoseTag.text = "Status: $status"
            binding.root.setOnClickListener { onItemClick(glucose) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GlucoseViewHolder {
        val binding = ListItemGlucoseBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return GlucoseViewHolder(binding)
    }

    override fun onBindViewHolder(holder: GlucoseViewHolder, position: Int) {
        val glucose = glucoses[position]
        holder.bind(glucose, onItemClick)
    }

    override fun getItemCount() = glucoses.size
}