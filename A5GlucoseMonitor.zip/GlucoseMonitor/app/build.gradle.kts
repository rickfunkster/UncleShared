plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
    id("com.google.devtools.ksp") version "1.9.0-1.0.13" // Add the KSP plugin
}

android {
    namespace = "edu.arizona.cast.rickfunk.glucosemonitor"
    compileSdk = 34

    defaultConfig {
        applicationId = "edu.arizona.cast.rickfunk.glucosemonitor"
        minSdk = 33
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    buildFeatures {
        viewBinding = true
    }

    // Add KSP-generated sources to the source set
    sourceSets {
        getByName("main").java.srcDir("build/generated/ksp/main/kotlin")
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)

    // Add Room dependencies with KSP
    implementation("androidx.room:room-runtime:2.5.0") // Room runtime dependency
    implementation("androidx.room:room-ktx:2.5.0") // Added Room KTX for coroutine support
    ksp("androidx.room:room-compiler:2.5.0") // Room compiler dependency for KSP

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.1")
    implementation("androidx.activity:activity-ktx:1.7.2")
}
