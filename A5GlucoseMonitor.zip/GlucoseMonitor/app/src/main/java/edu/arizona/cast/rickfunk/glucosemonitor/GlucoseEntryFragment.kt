package edu.arizona.cast.rickfunk.glucosemonitor

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.Spannable
import android.text.SpannableString
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment

class GlucoseEntryFragment : Fragment() {

    private lateinit var fastingInput: EditText
    private lateinit var breakfastInput: EditText
    private lateinit var lunchInput: EditText
    private lateinit var dinnerInput: EditText
    private lateinit var clearButton: Button
    private lateinit var historyButton: Button
    private lateinit var rangeMessage: TextView
    private lateinit var fastingTag: TextView
    private lateinit var breakfastTag: TextView
    private lateinit var lunchTag: TextView
    private lateinit var dinnerTag: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_glucose_entry, container, false)

        // Initialize UI components
        fastingInput = view.findViewById(R.id.fasting_input)
        breakfastInput = view.findViewById(R.id.breakfast_input)
        lunchInput = view.findViewById(R.id.lunch_input)
        dinnerInput = view.findViewById(R.id.dinner_input)
        clearButton = view.findViewById(R.id.clear_button)
        historyButton = view.findViewById(R.id.history_button)
        rangeMessage = view.findViewById(R.id.range_message)

        // Initialize tag messages
        fastingTag = view.findViewById(R.id.fasting_tag)
        breakfastTag = view.findViewById(R.id.breakfast_tag)
        lunchTag = view.findViewById(R.id.lunch_tag)
        dinnerTag = view.findViewById(R.id.dinner_tag)

        // Add text watcher to inputs
        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                calculateAndDisplayTags()
            }

            override fun afterTextChanged(s: Editable?) {}
        }

        fastingInput.addTextChangedListener(textWatcher)
        breakfastInput.addTextChangedListener(textWatcher)
        lunchInput.addTextChangedListener(textWatcher)
        dinnerInput.addTextChangedListener(textWatcher)

        // Clear button logic
        clearButton.setOnClickListener {
            clearInputs()
        }

        // Navigate to history fragment on history button click
        historyButton.setOnClickListener {
            navigateToHistory()
        }

        return view
    }

    private fun clearInputs() {
        fastingInput.text.clear()
        breakfastInput.text.clear()
        lunchInput.text.clear()
        dinnerInput.text.clear()
        rangeMessage.text = ""
        fastingTag.text = ""
        breakfastTag.text = ""
        lunchTag.text = ""
        dinnerTag.text = ""
    }

    private fun navigateToHistory() {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, GlucoseHistoryFragment())
            .addToBackStack(null)
            .commit()
    }

    private fun calculateAndDisplayTags() {
        val fasting = fastingInput.text.toString().toIntOrNull()
        val breakfast = breakfastInput.text.toString().toIntOrNull()
        val lunch = lunchInput.text.toString().toIntOrNull()
        val dinner = dinnerInput.text.toString().toIntOrNull()

        // Set individual tag messages
        fastingTag.text = getFastingTag(fasting)
        breakfastTag.text = getMealTag(breakfast)
        lunchTag.text = getMealTag(lunch)
        dinnerTag.text = getMealTag(dinner)

        // Display overall range message with "Glucose Status:"
        if (fasting != null && breakfast != null && lunch != null && dinner != null) {
            val average = (fasting + breakfast + lunch + dinner) / 4
            val statusMessage = when {
                fasting < 70 || average < 70 -> "Hypoglycemic"
                fasting in 70..99 && average <= 140 -> "Normal"
                else -> "Abnormal"
            }

            val styledMessage = applyColoring("Glucose Status: ", statusMessage)
            rangeMessage.text = styledMessage
        } else {
            rangeMessage.text = "Glucose Status: Enter all values to see range"
        }
    }

    private fun applyColoring(status: String, statusMessage: String): SpannableString {
        // Create a SpannableString to apply colors to different parts of the text
        val spannableString = SpannableString("$status$statusMessage")

        // Set "Glucose Status:" to black
        spannableString.setSpan(
            ForegroundColorSpan(Color.BLACK), 0, status.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        // Set the color of the status message
        val color = when (statusMessage) {
            "Normal" -> Color.GREEN
            "Abnormal" -> Color.RED
            "Hypoglycemic" -> Color.BLUE
            else -> Color.BLACK // Fallback to black if no matching status
        }

        // Apply color to the status message
        spannableString.setSpan(
            ForegroundColorSpan(color), status.length, spannableString.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        return spannableString
    }



    private fun getFastingTag(fasting: Int?): String {
        return when {
            fasting == null -> ""
            fasting < 70 -> "Hypoglycemic"
            fasting in 70..99 -> "Normal"
            else -> "Abnormal"
        }
    }

    private fun getMealTag(level: Int?): String {
        return when {
            level == null -> ""
            level > 140 -> "Abnormal"
            else -> "Normal"
        }
    }
}
