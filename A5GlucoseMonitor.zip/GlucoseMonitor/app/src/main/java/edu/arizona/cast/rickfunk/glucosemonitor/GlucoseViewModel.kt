package edu.arizona.cast.rickfunk.glucosemonitor

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect

private const val TAG = "GlucoseViewModel"

class GlucoseViewModel(private val repository: GlucoseRepository) : ViewModel() {

    // Correct declaration of StateFlow for a List of Glucose objects
    private val _glucoses = MutableStateFlow<List<Glucose>>(emptyList())
    val glucoses: StateFlow<List<Glucose>> = _glucoses.asStateFlow()

    init {
        // Collecting glucose data from the repository
        viewModelScope.launch {
            try {
                repository.getGlucoses().collect { glucoseList ->
                    Log.d(TAG, "Glucose data received: $glucoseList")
                    _glucoses.value = glucoseList
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error loading data.", e)
            }
        }
    }
}
