package edu.arizona.cast.rickfunk.glucosemonitor

import android.content.Context
import android.util.Log
import androidx.room.Room
import edu.arizona.cast.rickfunk.glucosemonitor.database.GlucoseDatabase
import kotlinx.coroutines.flow.Flow
import java.util.Date

private const val DATABASE_NAME = "glucose-database.db"
private const val TAG = "GlucoseRepository"

class GlucoseRepository private constructor(context: Context) {

    private val database: GlucoseDatabase = Room
        .databaseBuilder(
            context.applicationContext,
            GlucoseDatabase::class.java,
            DATABASE_NAME
        )
        .build() // Removed createFromAsset unless explicitly required.

    /**
     * Fetch all glucoses as a Flow.
     */
    fun getGlucoses(): Flow<List<Glucose>> {
        Log.d(TAG, "Fetching all glucoses from database.")
        return database.glucoseDao().getGlucoses()  // Correct method name
    }

    /**
     * Fetch glucose for a specific date.
     */
    suspend fun getGlucose(date: Date): Glucose? {  // Changed return type to nullable
        Log.d(TAG, "Fetching glucose for date: $date.")
        return database.glucoseDao().getGlucoseByDate(date)  // Corrected method name
    }

    companion object {
        @Volatile
        private var INSTANCE: GlucoseRepository? = null

        /**
         * Initialize the repository instance.
         */
        fun initialize(context: Context) {
            if (INSTANCE == null) {
                synchronized(this) {
                    if (INSTANCE == null) {
                        INSTANCE = GlucoseRepository(context)
                        Log.d(TAG, "GlucoseRepository initialized.")
                    }
                }
            }
        }

        /**
         * Retrieve the initialized repository instance.
         */
        fun get(): GlucoseRepository {
            return INSTANCE
                ?: throw IllegalStateException("GlucoseRepository must be initialized before use.")
        }
    }
}
