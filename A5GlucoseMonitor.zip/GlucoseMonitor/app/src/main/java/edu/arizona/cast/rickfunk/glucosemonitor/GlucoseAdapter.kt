package edu.arizona.cast.rickfunk.glucosemonitor

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import edu.arizona.cast.rickfunk.glucosemonitor.Glucose
import edu.arizona.cast.rickfunk.glucosemonitor.databinding.ListItemGlucoseBinding


class GlucoseAdapter(private val glucoseList: List<Glucose>) :
    RecyclerView.Adapter<GlucoseAdapter.GlucoseViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GlucoseViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item_glucose, parent, false)
        return GlucoseViewHolder(view)
    }

    override fun onBindViewHolder(holder: GlucoseViewHolder, position: Int) {
        val glucose = glucoseList[position]
        holder.blind(glucose)
        holder.itemView.setOnClickListener {
            Toast.makeText(holder.itemView.context, "Details: $glucose", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount() = glucoseList.size

    class GlucoseViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val dateView: TextView = view.findViewById(R.id.date)
        private val averageView: TextView = view.findViewById(R.id.average)
        private val abnormalCheckBox: CheckBox = view.findViewById(R.id.abnormal_checkbox)
        private val statusView: TextView = view.findViewById(R.id.glucose_status)

        fun blind(glucose: Glucose) {
            dateView.text = glucose.date.toString()
            val average = (glucose.fasting + glucose.breakfast + glucose.lunch + glucose.dinner) / 4
            averageView.text = "Avg: $average"
            abnormalCheckBox.isChecked = isAbnormal(glucose)

            if (glucose.isGlucoseNormal()) {
                statusView.text = "Normal"
                statusView.setTextColor(
                    ContextCompat.getColor(
                        itemView.context,
                        android.R.color.holo_green_dark
                    )
                )
            } else {
                statusView.text = "Abnormal"
                statusView.setTextColor(
                    ContextCompat.getColor(
                        itemView.context,
                        android.R.color.holo_red_dark
                    )
                )
            }
        }

        private fun isAbnormal(glucose: Glucose): Boolean {
            return glucose.fasting < 70 || glucose.fasting > 99 ||
                    glucose.breakfast > 140 || glucose.lunch > 140 || glucose.dinner > 140

        }

    }

    // Extension functions for Glucose class to clean up the adapter logic
    fun Glucose.calculateAverage(): Int {
        return (this.fasting + this.breakfast + this.lunch + this.dinner) / 4
    }

    fun Glucose.isGlucoseNormal(): Boolean {
        return this.fasting in 79..99 && this.breakfast <= 140 && this.lunch <= 140 && this.dinner <= 140
    }

    fun Glucose.getDetails(): String {
        return "Fasting: $fasting. Breakfast: $breakfast, Lunch: $lunch, Dinner: $dinner"
    }
}