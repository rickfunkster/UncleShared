package edu.arizona.cast.rickfunk.glucosemonitor.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import edu.arizona.cast.rickfunk.glucosemonitor.Glucose
import kotlinx.coroutines.flow.Flow
import java.util.Date

@Dao
interface GlucoseDao {
    @Insert
    suspend fun insert(glucose: Glucose)

    @Query("SELECT * FROM glucose_table WHERE date = :date")
    suspend fun getGlucoseByDate(date: Date): Glucose?

    @Query("SELECT * FROM glucose_table")
    fun getGlucoses(): Flow<List<Glucose>>  // Return Flow instead of List
}
