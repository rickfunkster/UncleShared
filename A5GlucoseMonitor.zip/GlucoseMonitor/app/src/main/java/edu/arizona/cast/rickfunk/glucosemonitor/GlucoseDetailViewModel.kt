package edu.arizona.cast.rickfunk.glucosemonitor

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class GlucoseDetailViewModel(): ViewModel() {

    private val _glucose = MutableLiveData(Glucose())
    val glucose: LiveData<Glucose> get() = _glucose
    fun updateFasting(fasting: Int) {
        _glucose.value = _glucose.value?.copy(fasting = fasting)
    }
    fun updateBreakfast(breakfast: Int) {
        _glucose.value = _glucose.value?.copy(breakfast = breakfast)
    }
    fun updateLunch(lunch: Int) {
        _glucose.value = _glucose.value?.copy(lunch = lunch)
    }
    fun updateDinner(dinner: Int) {
        _glucose.value = _glucose.value?.copy(dinner = dinner)
    }
    fun resetGlucose() {
        _glucose.value = Glucose()
    }
    override fun onCleared() {
        super.onCleared()
    }
}