package edu.arizona.cast.rickfunk.glucosemonitor

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.appcompat.widget.Toolbar  // Ensure this import is present

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Set up the toolbar if needed
        val toolbar: Toolbar = findViewById(R.id.toolbar) // This should match your toolbar ID in XML
        setSupportActionBar(toolbar)

        // Check if there is a saved instance state to avoid fragment duplication
        if (savedInstanceState == null) {
            // Load the GlucosesEntryFragment as the default fragment
            replaceFragment(GlucoseEntryFragment())
        }
    }

    // Function to replace the current fragment in the fragment container
    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null) // Add the transaction to the back of the stack so the user can navigate
            .commit()
    }

    // Optional: Function to navigate to GlucoseHistoryFragment when HISTORY button is clicked
    fun showHistory() {
        replaceFragment(GlucoseHistoryFragment())
    }
}
