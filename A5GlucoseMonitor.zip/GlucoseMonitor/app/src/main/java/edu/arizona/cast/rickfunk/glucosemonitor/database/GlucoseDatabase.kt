package edu.arizona.cast.rickfunk.glucosemonitor.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import edu.arizona.cast.rickfunk.glucosemonitor.Glucose
import edu.arizona.cast.rickfunk.glucosemonitor.Converters // Ensure this is the correct import for Converters
import edu.arizona.cast.rickfunk.glucosemonitor.database.GlucoseDao // Correctly import the GlucoseDao

@Database(entities = [Glucose::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class) // Register the TypeConverters for handling Date
abstract class GlucoseDatabase : RoomDatabase() {

    // DAO for Glucose operations
    abstract fun glucoseDao(): GlucoseDao

    companion object {
        @Volatile
        private var INSTANCE: GlucoseDatabase? = null
        private const val DATABASE_NAME = "glucose-database.db"

        // Singleton pattern to ensure only one instance of the database exists
        fun getInstance(context: Context): GlucoseDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    GlucoseDatabase::class.java,
                    DATABASE_NAME
                )
                    .build().also { INSTANCE = it }
            }
    }
}
