package edu.arizona.cast.rickfunk.glucosemonitor

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import java.util.*

@Entity(tableName = "glucose_table") // Annotate the class as a Room entity
data class Glucose(
    @PrimaryKey
    var date: Date = GregorianCalendar(
        Calendar.getInstance().get(Calendar.YEAR),
        Calendar.getInstance().get(Calendar.MONTH),
        Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
    ).time,
    var fasting: Int = -1,
    var breakfast: Int = -1,
    var lunch: Int = -1,
    var dinner: Int = -1
) {
    val avgGlucose: Int
        get() {
            val glucoseValues = listOf(fasting, breakfast, lunch, dinner)
            val validValues = glucoseValues.filter { it != -1 }
            return if (validValues.isNotEmpty()) validValues.sum() / validValues.size else -1
        }

    fun isGlucoseNormal(): Boolean {
        return fasting in 70..99 &&
                breakfast in 70..99 &&
                lunch in 70..99 &&
                dinner in 70..99
    }
}

// TypeConverters to allow Room to handle Date objects
class Converters {
    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }
}
