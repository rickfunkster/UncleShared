package edu.arizona.cast.rickfunk.glucosemonitor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import edu.arizona.cast.rickfunk.glucosemonitor.databinding.FragmentGlucoseHistoryBinding
import java.util.*

class GlucoseHistoryFragment : Fragment() {

    private var _binding: FragmentGlucoseHistoryBinding? = null
    private val binding get() = _binding!!

    private val glucoseList = generateSampleData()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentGlucoseHistoryBinding.inflate(inflater, container, false)

        // Set up RecyclerView with Adapter
        binding.glucoseRecyclerView.layoutManager = LinearLayoutManager(context)
        binding.glucoseRecyclerView.adapter = GlucoseAdapter(glucoseList)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // Sample data generator for Glucose objects
    private fun generateSampleData(): List<Glucose> {
        val glucoses = mutableListOf<Glucose>()
        val calendar = Calendar.getInstance()

        for (i in 0..10) { // Generate 10 sample entries
            val glucoseObject = Glucose(
                date = calendar.time,
                fasting = (60..180).random(),
                breakfast = (60..180).random(),
                lunch = (60..180).random(),
                dinner = (60..180).random()
            )
            calendar.add(Calendar.DATE, -1) // Move to the previous day
            glucoses.add(glucoseObject)
        }
        return glucoses
    }
}
